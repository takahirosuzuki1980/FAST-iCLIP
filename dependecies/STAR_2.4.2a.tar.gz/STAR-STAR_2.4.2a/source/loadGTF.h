#ifndef DEF_loadGTF
#define DEF_loadGTF
#include "Parameters.h"
#include "SjdbClass.h"
uint loadGTF(SjdbClass &sjdbLoci, Parameters *P, string dirOut);
#endif


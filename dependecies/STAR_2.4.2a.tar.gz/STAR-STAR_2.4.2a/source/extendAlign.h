#include "IncludeDefine.h"
#include "Parameters.h"
#include "Transcript.h"

bool extendAlign( char*, char*, char*, uint, uint, int, int, uint, uint, uint, uint, double, Transcript* );

#ifndef CODE_sjdbLoadFromStream
#define CODE_sjdbLoadFromStream

#include <fstream>
#include "SjdbClass.h"
void sjdbLoadFromStream(ifstream &sjdbStreamIn, SjdbClass &sjdbLoci);

#endif

#!/bin/bash

rm -f ./.star-fusion*ok
rm -f ./star-fusion.*txt

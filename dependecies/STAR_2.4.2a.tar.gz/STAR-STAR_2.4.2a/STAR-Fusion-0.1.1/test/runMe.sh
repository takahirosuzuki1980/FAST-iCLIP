#!/bin/bash


../STAR-Fusion -S Chimeric.out.sam.gz -J Chimeric.out.junction.gz
